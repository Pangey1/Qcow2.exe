﻿#include <windows.h>
#include <mmsystem.h>
#include <gdiplus.h>
#include <d2d1.h>
#include <dwrite.h>
#include <commctrl.h>
#include <shlobj.h>
#include <cmath>
#include <vector>
#include <string>
#include <random>
#include <thread>
#include <atomic>
#include <mutex>
#include <algorithm>
#include <chrono>
#include <iostream>
std::atomic<bool> isRunning{ true };
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "msimg32.lib")
#pragma comment(lib, "gdiplus.lib")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "comctl32.lib")
#define M_PI   3.14159265358979323846264338327950288
typedef LONG(NTAPI* NRHEdef)(LONG, ULONG, ULONG, PULONG_PTR, ULONG, PULONG);
typedef LONG(NTAPI* RAPdef)(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
typedef NTSTATUS(NTAPI* RSPICdef)(BOOLEAN NewValue, PBOOLEAN OldValue, BOOLEAN IsWinlogon);
struct HSL {
    float h;
    float s;
    float l;
};

namespace Colors {
    HSL rgb2hsl(RGBQUAD rgb) {
        float r = rgb.rgbRed / 255.0f;
        float g = rgb.rgbGreen / 255.0f;
        float b = rgb.rgbBlue / 255.0f;

        float maxVal = (std::max)({ r, g, b });
        float minVal = (std::min)({ r, g, b });
        float h = 0.0f, s = 0.0f, l = (maxVal + minVal) / 2.0f;

        if (maxVal != minVal) {
            float d = maxVal - minVal;
            s = l > 0.5f ? d / (2.0f - maxVal - minVal) : d / (maxVal + minVal);
            if (maxVal == r) {
                h = (g - b) / d + (g < b ? 6.0f : 0.0f);
            }
            else if (maxVal == g) {
                h = (b - r) / d + 2.0f;
            }
            else {
                h = (r - g) / d + 4.0f;
            }
            h /= 6.0f;
        }
        return { h, s, l };
    }

    float hue2rgb(float p, float q, float t) {
        if (t < 0.0f) t += 1.0f;
        if (t > 1.0f) t -= 1.0f;
        if (t < 1.0f / 6.0f) return p + (q - p) * 6.0f * t;
        if (t < 1.0f / 2.0f) return q;
        if (t < 2.0f / 3.0f) return p + (q - p) * (2.0f / 3.0f - t) * 6.0f;
        return p;
    }

    RGBQUAD hsl2rgb(HSL hsl) {
        float r, g, b;
        if (hsl.s == 0.0f) {
            r = g = b = hsl.l;
        }
        else {
            float q = hsl.l < 0.5f ? hsl.l * (1.0f + hsl.s) : hsl.l + hsl.s - hsl.l * hsl.s;
            float p = 2.0f * hsl.l - q;
            r = hue2rgb(p, q, hsl.h + 1.0f / 3.0f);
            g = hue2rgb(p, q, hsl.h);
            b = hue2rgb(p, q, hsl.h - 1.0f / 3.0f);
        }
        RGBQUAD res = { 0 };
        res.rgbRed = static_cast<BYTE>((std::min)((std::max)(r * 255.0f, 0.0f), 255.0f));
        res.rgbGreen = static_cast<BYTE>((std::min)((std::max)(g * 255.0f, 0.0f), 255.0f));
        res.rgbBlue = static_cast<BYTE>((std::min)((std::max)(b * 255.0f, 0.0f), 255.0f));
        return res;
    }
}
DWORD WINAPI Sound1(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 0;
    }

    const DWORD sampleRate = 22050;
    const DWORD durationSec = 30;
    const DWORD totalSamples = sampleRate * durationSec;
    std::vector<BYTE> buffer(totalSamples);

    for (DWORD t = 0; t < totalSamples; ++t) {
        buffer[t] = static_cast<BYTE>((1 * t & t * (t >> 11) / 7));
    }

    WAVEHDR header = { 0 };
    header.lpData = reinterpret_cast<LPSTR>(buffer.data());
    header.dwBufferLength = totalSamples;

    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    ULONGLONG startTime = GetTickCount64();
    while (isRunning && (GetTickCount64() - startTime < durationSec * 1000)) {
        if (header.dwFlags & WHDR_DONE) {
            break;
        }
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);

    return 0;
}
DWORD WINAPI Sound2(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    const DWORD outRate = 44100;
    const DWORD origRate = 8000;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, outRate, outRate, 1, 8, 0 };
    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 0;
    }

    const DWORD durationSec = 30;
    const DWORD bufferSize = outRate * durationSec;
    std::vector<char> buffer(bufferSize);

    for (DWORD i = 0; i < bufferSize; ++i) {
        int it = static_cast<int>((static_cast<unsigned long long>(i) * origRate) / outRate);
        buffer[i] = static_cast<char>((it >> 6 & it * 6 & it >> 7 ^ it >> 4 & it + (it >> 6 & -it) | it >> 3));
    }

    WAVEHDR header = { buffer.data(), bufferSize, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    ULONGLONG startTime = GetTickCount64();
    while (isRunning && (GetTickCount64() - startTime < 30000)) {
        if (header.dwFlags & WHDR_DONE) break;
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
    return 0;
}

DWORD WINAPI Sound3(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    const DWORD outRate = 44100;
    const DWORD origRate = 11025;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, outRate, outRate, 1, 8, 0 };
    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 0;
    }

    const DWORD durationSec = 30;
    const DWORD bufferSize = outRate * durationSec;
    std::vector<char> buffer(bufferSize);

    for (DWORD i = 0; i < bufferSize; ++i) {
        unsigned int ut = static_cast<unsigned int>((static_cast<unsigned long long>(i) * origRate) / outRate);
        buffer[i] = static_cast<char>((ut + ut) & (ut >> ((50 + (ut >> 2)) & 31)) & (ut >> 5));
    }

    WAVEHDR header = { buffer.data(), bufferSize, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    ULONGLONG startTime = GetTickCount64();
    while (isRunning && (GetTickCount64() - startTime < 30000)) {
        if (header.dwFlags & WHDR_DONE) break;
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
    return 0;
}
DWORD WINAPI Sound4(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 0;
    }

    const DWORD sampleRate = 8000;
    const DWORD durationSec = 30;
    const DWORD bufferSize = sampleRate * durationSec;
    std::vector<char> buffer(bufferSize);

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = static_cast<char>((t >> 5 & (t >> 2) * (t >> 5)));
    }

    WAVEHDR header = { buffer.data(), bufferSize, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    ULONGLONG startTime = GetTickCount64();
    while (isRunning && (GetTickCount64() - startTime < 30000)) {
        if (header.dwFlags & WHDR_DONE) break;
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
    return 0;
}
DWORD WINAPI Sound5(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 0;
    }

    const DWORD sampleRate = 8000;
    const DWORD durationSec = 30;
    const DWORD bufferSize = sampleRate * durationSec;
    std::vector<char> buffer(bufferSize);

    for (DWORD t = 0; t < bufferSize; ++t) {
        int it = static_cast<int>(t);
        int denom = it & 12;
        if (denom != 0) {
            buffer[t] = static_cast<char>((((it / denom) * it) >> 3) & ((-it) / denom));
        }
        else {
            buffer[t] = 0;
        }
    }

    WAVEHDR header = { buffer.data(), bufferSize, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    ULONGLONG startTime = GetTickCount64();
    while (isRunning && (GetTickCount64() - startTime < 30000)) {
        if (header.dwFlags & WHDR_DONE) break;
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
    return 0;
}
DWORD WINAPI Sound6(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 11025, 11025, 1, 8, 0 };
    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 0;
    }

    const DWORD sampleRate = 11025;
    const DWORD durationSec = 30;
    const DWORD bufferSize = sampleRate * durationSec;
    std::vector<char> buffer(bufferSize);

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = static_cast<char>(((t >> 6) ^ (t * 3)) + t);
    }

    WAVEHDR header = { buffer.data(), bufferSize, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    ULONGLONG startTime = GetTickCount64();
    while (isRunning && (GetTickCount64() - startTime < 30000)) {
        if (header.dwFlags & WHDR_DONE) break;
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
    return 0;
}
DWORD WINAPI Sound7(LPVOID lpParam) {
    HWAVEOUT hWaveOut = NULL;
    WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 16000, 16000, 1, 8, 0 };
    if (waveOutOpen(&hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL) != MMSYSERR_NOERROR) {
        return 0;
    }

    const DWORD sampleRate = 16000;
    const DWORD durationSec = 30;
    const DWORD bufferSize = sampleRate * durationSec;
    std::vector<char> buffer(bufferSize);

    for (DWORD t = 0; t < bufferSize; ++t) {
        buffer[t] = static_cast<char>((((t & 0x40) + t) & (t >> 4)) | (t >> 7));
    }

    WAVEHDR header = { buffer.data(), bufferSize, 0, 0, 0, 0, 0, 0 };
    waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

    ULONGLONG startTime = GetTickCount64();
    while (isRunning && (GetTickCount64() - startTime < 30000)) {
        if (header.dwFlags & WHDR_DONE) break;
        Sleep(50);
    }

    waveOutReset(hWaveOut);
    waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
    waveOutClose(hWaveOut);
    return 0;
}
DWORD WINAPI Figures(LPVOID lpParam) {
    int width = GetSystemMetrics(SM_CXSCREEN);
    int height = GetSystemMetrics(SM_CYSCREEN);

    std::mt19937 rng(static_cast<unsigned int>(GetTickCount64()));
    const wchar_t* dlls[] = { L"moricons.dll", L"imageres.dll" };

    int morCount = ExtractIconExW(dlls[0], -1, NULL, NULL, 0);
    int imgCount = ExtractIconExW(dlls[1], -1, NULL, NULL, 0);
    if (morCount <= 0) morCount = 100;
    if (imgCount <= 0) imgCount = 300;

    auto getRandomIcon = [&]() -> HICON {
        for (int attempt = 0; attempt < 15; ++attempt) {
            int dllIdx = std::uniform_int_distribution<int>(0, 1)(rng);
            int maxIdx = (dllIdx == 0) ? morCount : imgCount;
            int iconIdx = std::uniform_int_distribution<int>(0, maxIdx - 1)(rng);
            HICON hIcon = NULL;
            if (ExtractIconExW(dlls[dllIdx], iconIdx, &hIcon, NULL, 1) > 0 && hIcon != NULL) {
                return hIcon;
            }
        }
        return LoadIconW(NULL, IDI_APPLICATION);
        };

    const int sidesList[] = { 3, 4, 6 };
    int currentSides = sidesList[std::uniform_int_distribution<int>(0, 2)(rng)];
    float radius = 140.0f;
    const int linksPerEdge = 6;

    std::vector<HICON> linkIcons;
    HICON innerIcon = LoadIconW(NULL, IDI_ERROR);

    auto rebuildIcons = [&]() {
        for (HICON hIcon : linkIcons) {
            if (hIcon) DestroyIcon(hIcon);
        }
        int totalLinks = currentSides * linksPerEdge;
        linkIcons.resize(totalLinks);
        for (int i = 0; i < totalLinks; ++i) {
            linkIcons[i] = getRandomIcon();
        }
        bool useWarning = (std::uniform_int_distribution<int>(0, 1)(rng) == 1);
        innerIcon = LoadIconW(NULL, useWarning ? IDI_WARNING : IDI_ERROR);
        };

    rebuildIcons();

    float cx = static_cast<float>(width / 2);
    float cy = static_cast<float>(height / 2);
    float vx = 6.0f;
    float vy = 5.0f;

    ULONGLONG lastChangeTime = GetTickCount64();

    while (true) {
        ULONGLONG now = GetTickCount64();
        if (now - lastChangeTime >= 1000) {
            lastChangeTime = now;
            currentSides = sidesList[std::uniform_int_distribution<int>(0, 2)(rng)];
            rebuildIcons();
        }

        cx += vx;
        cy += vy;

        float margin = radius + 16.0f;
        if (cx - margin < 0.0f) {
            cx = margin;
            vx = -vx;
        }
        else if (cx + margin > static_cast<float>(width)) {
            cx = static_cast<float>(width) - margin;
            vx = -vx;
        }

        if (cy - margin < 0.0f) {
            cy = margin;
            vy = -vy;
        }
        else if (cy + margin > static_cast<float>(height)) {
            cy = static_cast<float>(height) - margin;
            vy = -vy;
        }

        HDC hdc = GetDC(NULL);
        if (hdc) {
            std::vector<POINT> verts(currentSides);
            for (int i = 0; i < currentSides; ++i) {
                float angle = (2.0f * 3.14159265f * static_cast<float>(i)) / static_cast<float>(currentSides) - (3.14159265f / 2.0f);
                verts[i].x = static_cast<LONG>(cx + radius * std::cos(angle));
                verts[i].y = static_cast<LONG>(cy + radius * std::sin(angle));
            }

            int step = 28;
            int rInt = static_cast<int>(radius * 0.65f);
            for (int dy = -rInt; dy <= rInt; dy += step) {
                for (int dx = -rInt; dx <= rInt; dx += step) {
                    int px = static_cast<int>(cx) + dx;
                    int py = static_cast<int>(cy) + dy;
                    bool inside = true;
                    for (int i = 0; i < currentSides; ++i) {
                        int next = (i + 1) % currentSides;
                        float cross = static_cast<float>((verts[next].x - verts[i].x) * (py - verts[i].y) - (verts[next].y - verts[i].y) * (px - verts[i].x));
                        if (cross < 0.0f) {
                            inside = false;
                            break;
                        }
                    }
                    if (inside && innerIcon) {
                        DrawIconEx(hdc, px - 14, py - 14, innerIcon, 28, 28, 0, NULL, DI_NORMAL);
                    }
                }
            }

            int iconIdx = 0;
            for (int i = 0; i < currentSides; ++i) {
                int next = (i + 1) % currentSides;
                for (int s = 0; s < linksPerEdge; ++s) {
                    float t = static_cast<float>(s) / static_cast<float>(linksPerEdge);
                    int ix = static_cast<int>(verts[i].x + (verts[next].x - verts[i].x) * t) - 16;
                    int iy = static_cast<int>(verts[i].y + (verts[next].y - verts[i].y) * t) - 16;
                    if (iconIdx < static_cast<int>(linkIcons.size()) && linkIcons[iconIdx]) {
                        DrawIconEx(hdc, ix, iy, linkIcons[iconIdx], 32, 32, 0, NULL, DI_NORMAL);
                    }
                    iconIdx++;
                }
            }

            ReleaseDC(NULL, hdc);
        }

        Sleep(15);
    }

    return 0;
}
DWORD WINAPI Payload1(LPVOID lpParam) {
    HDC hdc = GetDC(NULL);
    HDC hdcCopy = CreateCompatibleDC(hdc);
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    BITMAPINFO bmpi = { 0 };
    HBITMAP bmp;

    bmpi.bmiHeader.biSize = sizeof(bmpi);
    bmpi.bmiHeader.biWidth = w;
    bmpi.bmiHeader.biHeight = h;
    bmpi.bmiHeader.biPlanes = 1;
    bmpi.bmiHeader.biBitCount = 32;
    bmpi.bmiHeader.biCompression = BI_RGB;

    RGBQUAD* rgbquad = NULL;
    HSL hslcolor;

    bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
    SelectObject(hdcCopy, bmp);
    ReleaseDC(NULL, hdc);

    INT i = 0;

    while (isRunning)
    {
        hdc = GetDC(NULL);
        StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

        RGBQUAD rgbquadCopy;

        for (int x = 0; x < w; x++)
        {
            for (int y = 0; y < h; y++)
            {
                int index = y * w + x;

                int fx = (int)((4 * i) + ((4 * i) * sin(x / 16.0)) + (4 * i) + ((4 * i) * sin(y / 8.0)));

                rgbquadCopy = rgbquad[index];

                hslcolor = Colors::rgb2hsl(rgbquadCopy);
                hslcolor.h = fmod(fx / 300.f + y / (float)h * .1f, 1.f);
                hslcolor.s = 1.0f;
                hslcolor.l = 0.5f;

                rgbquad[index] = Colors::hsl2rgb(hslcolor);
            }
        }

        i++;
        StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, SRCCOPY);
        ReleaseDC(NULL, hdc);
        Sleep(10);
    }

    DeleteObject(bmp);
    DeleteDC(hdcCopy);
    return 0x00;
}

DWORD WINAPI rgb(LPVOID lpParam) {
    HDC hdcScreen = GetDC(0);
    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    INT w = GetSystemMetrics(0);
    INT h = GetSystemMetrics(1);

    BITMAPINFO bmi = { 0 };
    bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biWidth = w;
    bmi.bmiHeader.biHeight = h;

    RGBQUAD* rgbScreen = nullptr;
    HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, (void**)&rgbScreen, NULL, NULL);
    SelectObject(hdcMem, hbmTemp);
    ReleaseDC(NULL, hdcScreen);

    float shift = 0.0f;

    while (isRunning) {
        hdcScreen = GetDC(0);
        BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);

        for (INT y = 0; y < h; y++) {
            for (INT x = 0; x < w; x++) {
                INT i = y * w + x;
                HSL hsl = Colors::rgb2hsl(rgbScreen[i]);
                hsl.h = fmod((x + y) / 400.0f + shift, 1.0f);
                hsl.s = 1.0f;
                hsl.l = 0.5f;
                rgbScreen[i] = Colors::hsl2rgb(hsl);
            }
        }

        BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
        ReleaseDC(NULL, hdcScreen);
        shift += 0.02f;
        Sleep(10);
    }

    DeleteObject(hbmTemp);
    DeleteDC(hdcMem);
    return 0;
}
DWORD WINAPI Ball(LPVOID lpParam) {
    int w = GetSystemMetrics(0);
    int h = GetSystemMetrics(1);
    int xf = 0;
    int yf = 0;
    int signX = 15;
    int signY = 5;
    HDC hdc = GetDC(0);
    HBITMAP hbmTemp = CreateCompatibleBitmap(hdc, w, h);
    HDC hdcTemp = CreateCompatibleDC(hdc);
    HBRUSH hbrInit = CreateSolidBrush(RGB(225, 0, 0));
    SelectObject(hdcTemp, hbmTemp);
    ReleaseDC(0, hdc);

    int radius = 100;
    double angle = 0;
    int x, y;
    int centerX, centerY;
    int origX = (w / 4) - (radius / 2), origY = (h / 4) - (radius / 2);

    while (isRunning)
    {
        hdc = GetDC(0);
        xf += signX;
        yf += signY;
        centerX = origX - (w / 4), centerY = origY - (h / 4);
        x = static_cast<int>((cos(angle) * radius) + centerX);
        y = static_cast<int>((sin(angle) * radius) + centerY);

        for (INT i = 64; i > 8; i -= 8)
        {
            HBRUSH hbr = CreateSolidBrush(RGB(225, 0, 0));
            HGDIOBJ oldBr = SelectObject(hdc, hbr);
            Ellipse(hdc, 50 + x - i + xf, 50 + y - i + yf, 100 + x + i + xf, 100 + y + i + yf);
            SelectObject(hdc, oldBr);
            DeleteObject(hbr);
        }

        angle = fmod(angle + 3.14159265358979323846 / radius, 3.14159265358979323846 * radius);
        Sleep(10);

        if (yf == 0)
        {
            signY = 5;
        }

        if (xf == 0)
        {
            signX = 15;
        }

        if (yf >= GetSystemMetrics(1))
        {
            signY -= 5;
        }

        if (xf >= GetSystemMetrics(0))
        {
            signX -= 15;
        }
        ReleaseDC(0, hdc);
    }

    DeleteObject(hbrInit);
    DeleteObject(hbmTemp);
    DeleteDC(hdcTemp);
    return 0;
}
DWORD WINAPI Payload2(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    int dx = 4;
    int dy = 4;

    while (isRunning) {
        HDC hdc = GetDC(NULL);
        if (hdc) {
            HDC hdcMem = CreateCompatibleDC(hdc);
            HBITMAP hbm = CreateCompatibleBitmap(hdc, w, h);
            HGDIOBJ oldObj = SelectObject(hdcMem, hbm);

            BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

            BitBlt(hdc, dx, dy, w - dx, h - dy, hdcMem, 0, 0, SRCCOPY);
            BitBlt(hdc, 0, dy, dx, h - dy, hdcMem, w - dx, 0, SRCCOPY);
            BitBlt(hdc, dx, 0, w - dx, dy, hdcMem, 0, h - dy, SRCCOPY);
            BitBlt(hdc, 0, 0, dx, dy, hdcMem, w - dx, h - dy, SRCCOPY);

            SelectObject(hdcMem, oldObj);
            DeleteObject(hbm);
            DeleteDC(hdcMem);
            ReleaseDC(NULL, hdc);
        }
        Sleep(15);
    }
    return 0;
}

DWORD WINAPI Shader2(LPVOID lpParam) {
    while (isRunning) {
        HDC hdc = GetDC(HWND_DESKTOP);
        int sw = GetSystemMetrics(SM_CXSCREEN), sh = GetSystemMetrics(SM_CYSCREEN);
        BitBlt(hdc, rand() % 5, rand() % 5, rand() % sw, rand() % sh, hdc, rand() % 5, rand() % 5, SRCPAINT);
        ReleaseDC(0, hdc);
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Payload3(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);

    std::mt19937 rng(static_cast<unsigned int>(GetTickCount64()));
    const DWORD ropFlags[] = {
        SRCCOPY,
        SRCPAINT,
        SRCAND,
        SRCINVERT,
        SRCERASE,
        NOTSRCCOPY,
        NOTSRCERASE,
        MERGECOPY,
        MERGEPAINT,
        PATCOPY,
        PATPAINT,
        PATINVERT,
        DSTINVERT,
        0x999999
    };
    const int ropCount = sizeof(ropFlags) / sizeof(ropFlags[0]);

    while (isRunning) {
        int bx = std::uniform_int_distribution<int>(0, (std::max)(1, w - 50))(rng);
        int by = std::uniform_int_distribution<int>(0, (std::max)(1, h - 50))(rng);
        int bw = std::uniform_int_distribution<int>(40, (std::max)(41, w - bx))(rng);
        int bh = std::uniform_int_distribution<int>(40, (std::max)(41, h - by))(rng);
        int steps = std::uniform_int_distribution<int>(8, 25)(rng);
        int stepY = std::uniform_int_distribution<int>(2, 8)(rng);

        DWORD rop = ropFlags[std::uniform_int_distribution<int>(0, ropCount - 1)(rng)];
        COLORREF randColor = RGB(
            std::uniform_int_distribution<int>(0, 255)(rng),
            std::uniform_int_distribution<int>(0, 255)(rng),
            std::uniform_int_distribution<int>(0, 255)(rng)
        );

        int curY = by;
        for (int s = 0; s < steps && isRunning; ++s) {
            if (curY + stepY >= h) break;

            HDC hdc = GetDC(NULL);
            if (hdc) {
                HBRUSH hBrush = CreateSolidBrush(randColor);
                HGDIOBJ oldBrush = SelectObject(hdc, hBrush);

                BitBlt(hdc, bx, curY + stepY, bw, bh, hdc, bx, curY, rop);

                SelectObject(hdc, oldBrush);
                DeleteObject(hBrush);
                ReleaseDC(NULL, hdc);
            }
            curY += stepY;
            Sleep(15);
        }
    }
    return 0;
}
DWORD WINAPI Payload4(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    std::mt19937 rng(static_cast<unsigned int>(GetTickCount64()));
    bool verticalSplit = true;

    while (isRunning) {
        HDC hdc = GetDC(NULL);
        if (hdc) {
            COLORREF c1 = RGB(
                std::uniform_int_distribution<int>(0, 255)(rng),
                std::uniform_int_distribution<int>(0, 255)(rng),
                std::uniform_int_distribution<int>(0, 255)(rng)
            );
            COLORREF c2 = RGB(
                std::uniform_int_distribution<int>(0, 255)(rng),
                std::uniform_int_distribution<int>(0, 255)(rng),
                std::uniform_int_distribution<int>(0, 255)(rng)
            );

            HBRUSH b1 = CreateSolidBrush(c1);
            HBRUSH b2 = CreateSolidBrush(c2);

            if (verticalSplit) {
                int halfW = w / 2;
                HGDIOBJ old = SelectObject(hdc, b1);
                PatBlt(hdc, 0, 0, halfW, h, PATINVERT);
                SelectObject(hdc, b2);
                PatBlt(hdc, halfW, 0, w - halfW, h, PATINVERT);
                SelectObject(hdc, old);
            }
            else {
                int halfH = h / 2;
                HGDIOBJ old = SelectObject(hdc, b1);
                PatBlt(hdc, 0, 0, w, halfH, PATINVERT);
                SelectObject(hdc, b2);
                PatBlt(hdc, 0, halfH, w, h - halfH, PATINVERT);
                SelectObject(hdc, old);
            }

            DeleteObject(b1);
            DeleteObject(b2);
            ReleaseDC(NULL, hdc);
        }
        verticalSplit = !verticalSplit;
        Sleep(80);
    }
    return 0;
}
DWORD WINAPI Payload5(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    std::mt19937 rng(static_cast<unsigned int>(GetTickCount64()));
    std::uniform_int_distribution<int> xDist(0, (std::max)(1, w));
    std::uniform_int_distribution<int> wDist(10, 60);
    std::uniform_int_distribution<int> yOffDist(1, 15);
    std::uniform_int_distribution<int> colDist(0, 255);

    while (isRunning) {
        HDC hdc = GetDC(NULL);
        if (hdc) {
            int x = xDist(rng);
            int bw = wDist(rng);
            int dy = yOffDist(rng);

            HBRUSH hBrush = CreateSolidBrush(RGB(colDist(rng), colDist(rng), colDist(rng)));
            HGDIOBJ oldBrush = SelectObject(hdc, hBrush);

            BitBlt(hdc, x, dy, bw, h - dy, hdc, x, 0, 0x999999);

            SelectObject(hdc, oldBrush);
            DeleteObject(hBrush);
            ReleaseDC(NULL, hdc);
        }
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Payload6(LPVOID lpParam) {
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    int rx;
    while (isRunning) {
        HDC hdc = GetDC(0);
        if (hdc) {
            rx = rand() % sw;
            int ry = rand() % sh;
            BitBlt(hdc, rx, 10, 100, sh, hdc, rx, 0, SRCCOPY);
            BitBlt(hdc, rx, -10, -100, sh, hdc, rx, 0, SRCCOPY);
            BitBlt(hdc, 10, ry, sw, 96, hdc, 0, ry, SRCCOPY);
            BitBlt(hdc, -10, ry, sw, -96, hdc, 0, ry, SRCCOPY);
            ReleaseDC(0, hdc);
        }
        Sleep(10);
    }
    return 0;
}
DWORD WINAPI Textout(LPVOID lpParam) {
    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);
    std::mt19937 rng(static_cast<unsigned int>(GetTickCount64()));
    std::uniform_int_distribution<int> colDist(0, 255);

    const wchar_t* text = L"Qcow2.exe";
    int textLen = lstrlenW(text);

    int x = sw / 2;
    int y = sh / 2;
    int vx = 5;
    int vy = 4;

    HFONT hFont = CreateFontW(
        64, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI"
    );

    while (isRunning) {
        HDC hdc = GetDC(NULL);
        if (hdc) {
            HGDIOBJ oldFont = SelectObject(hdc, hFont);
            SIZE textSize = { 0, 0 };
            GetTextExtentPoint32W(hdc, text, textLen, &textSize);

            x += vx;
            y += vy;

            if (x < 0) {
                x = 0;
                vx = -vx;
            }
            else if (x + textSize.cx > sw) {
                x = (std::max)(0, static_cast<int>(sw - textSize.cx));
                vx = -vx;
            }

            if (y < 0) {
                y = 0;
                vy = -vy;
            }
            else if (y + textSize.cy > sh) {
                y = (std::max)(0, static_cast<int>(sh - textSize.cy));
                vy = -vy;
            }

            SetBkMode(hdc, TRANSPARENT);
            SetTextColor(hdc, RGB(colDist(rng), colDist(rng), colDist(rng)));

            TextOutW(hdc, x, y, text, textLen);

            SelectObject(hdc, oldFont);
            ReleaseDC(NULL, hdc);
        }
        Sleep(15);
    }

    if (hFont) DeleteObject(hFont);
    return 0;
}
DWORD WINAPI Payload7(LPVOID lpParam) {
    int w = GetSystemMetrics(SM_CXSCREEN);
    int h = GetSystemMetrics(SM_CYSCREEN);
    std::mt19937 rng(static_cast<unsigned int>(GetTickCount64()));
    std::uniform_int_distribution<int> colDist(0, 255);

    while (isRunning) {
        HDC hdc = GetDC(NULL);
        if (hdc) {
            HBRUSH hBrush = CreateSolidBrush(RGB(colDist(rng), colDist(rng), colDist(rng)));
            HGDIOBJ oldBrush = SelectObject(hdc, hBrush);

            PatBlt(hdc, 0, 0, w, h, PATINVERT);

            SelectObject(hdc, oldBrush);
            DeleteObject(hBrush);
            ReleaseDC(NULL, hdc);
        }
        Sleep(15);
    }
    return 0;
}
DWORD WINAPI Waves(LPVOID lpParam) {
    float phase = 0.0f;

    while (isRunning) {
        int w = GetSystemMetrics(SM_CXSCREEN);
        int h = GetSystemMetrics(SM_CYSCREEN);
        if (w <= 0 || h <= 0) {
            Sleep(50);
            continue;
        }

        HDC hdc = GetDC(NULL);
        if (hdc) {
            HDC hdcMem = CreateCompatibleDC(hdc);
            HBITMAP hbm = CreateCompatibleBitmap(hdc, w, h);
            if (hdcMem && hbm) {
                HGDIOBJ oldObj = SelectObject(hdcMem, hbm);

                BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

                for (int x = 0; x < w; x += 4) {
                    int dy = static_cast<int>(std::sin((static_cast<float>(x) / static_cast<float>(w)) * 6.283185f + phase) * 28.0f);
                    if (dy > 0 && dy < h) {
                        BitBlt(hdc, x, dy, 4, h - dy, hdcMem, x, 0, SRCCOPY);
                        BitBlt(hdc, x, 0, 4, dy, hdcMem, x, h - dy, SRCCOPY);
                    }
                    else if (dy < 0 && -dy < h) {
                        int ady = -dy;
                        BitBlt(hdc, x, 0, 4, h - ady, hdcMem, x, ady, SRCCOPY);
                        BitBlt(hdc, x, h - ady, 4, ady, hdcMem, x, 0, SRCCOPY);
                    }
                }

                BitBlt(hdcMem, 0, 0, w, h, hdc, 0, 0, SRCCOPY);

                for (int y = 0; y < h; y += 4) {
                    int dx = static_cast<int>(std::sin((static_cast<float>(y) / static_cast<float>(h)) * 12.56637f + phase * 1.5f) * 28.0f);
                    if (dx > 0 && dx < w) {
                        BitBlt(hdc, dx, y, w - dx, 4, hdcMem, 0, y, SRCCOPY);
                        BitBlt(hdc, 0, y, dx, 4, hdcMem, w - dx, y, SRCCOPY);
                    }
                    else if (dx < 0 && -dx < w) {
                        int adx = -dx;
                        BitBlt(hdc, 0, y, w - adx, 4, hdcMem, adx, y, SRCCOPY);
                        BitBlt(hdc, w - adx, y, adx, 4, hdcMem, 0, y, SRCCOPY);
                    }
                }

                SelectObject(hdcMem, oldObj);
            }
            if (hbm) DeleteObject(hbm);
            if (hdcMem) DeleteDC(hdcMem);
            ReleaseDC(NULL, hdc);
        }
        phase += 0.25f;
        Sleep(15);
    }
    return 0;
}
void RunStage(const std::vector<LPTHREAD_START_ROUTINE>& funcs, DWORD durationMs) {
    isRunning = true;
    std::vector<HANDLE> handles;
    for (auto func : funcs) {
        HANDLE hThread = CreateThread(NULL, 0, func, NULL, 0, NULL);
        if (hThread) {
            handles.push_back(hThread);
        }
    }

    Sleep(durationMs);

    isRunning = false;
    if (!handles.empty()) {
        WaitForMultipleObjects(static_cast<DWORD>(handles.size()), handles.data(), TRUE, INFINITE);
        for (HANDLE h : handles) {
            CloseHandle(h);
        }
    }

    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    Sleep(100);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    SetProcessDPIAware();

    if (MessageBoxW(NULL, L"Warning! You have torjan known as qcow2.exe Do you want to continue?", L"Qcow2.exe", MB_YESNO | MB_ICONWARNING) != IDYES) {
        return 0;
    }

    if (MessageBoxW(NULL, L"Final warning! This is a FULL delete you system and data! This NOT FOR epileptics!!!! Continiume?", L"Qcow2.exe", MB_YESNO | MB_ICONWARNING) != IDYES) {
        return 0;
    }
    Sleep(5000);

    HANDLE hFigures = CreateThread(NULL, 0, Figures, NULL, 0, NULL);
    if (hFigures) {
        CloseHandle(hFigures);
    }

    RunStage({ rgb, Sound1 }, 30000);
    RunStage({ Payload2, Shader2, Ball, Sound2 }, 30000);
    RunStage({ Payload3, Sound3 }, 30000);
    RunStage({ Payload4, Sound4 }, 30000);
    RunStage({ Payload5, Sound5 }, 30000);
    RunStage({ Payload6, Textout, Sound6 }, 30000);
    RunStage({ Payload7, Waves, Sound7 }, 30000);
    RedrawWindow(NULL, NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_ALLCHILDREN);
    ExitProcess(0);
    return 0;
}