@Echo off
nasm.exe -f bin 090618112026.asm -o disk.img
pause
qemu\qemu disk.img
HxD\HxD64 disk.img